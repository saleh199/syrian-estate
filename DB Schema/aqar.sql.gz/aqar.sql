-- Adminer 4.1.0 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `aqar` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `aqar`;

DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1,	'admin',	'Administrator'),
(2,	'members',	'General User');

DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `project`;
CREATE TABLE `project` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `address` text NOT NULL,
  `area` varchar(25) NOT NULL,
  `description` text NOT NULL,
  `services` text NOT NULL,
  `youtube_url` tinytext NOT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `project_image`;
CREATE TABLE `project_image` (
  `project_image_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `description` tinytext NOT NULL,
  `project_image_type` char(1) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`project_image_id`),
  KEY `project_id` (`project_id`),
  CONSTRAINT `project_fk` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `property`;
CREATE TABLE `property` (
  `property_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `property_type_id` int(11) NOT NULL,
  `property_status_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `price` int(20) NOT NULL,
  `area` int(20) NOT NULL,
  `zone_id` int(11) NOT NULL,
  `map_lat` varchar(200) NOT NULL,
  `map_lng` varchar(200) NOT NULL,
  `map_zoom` tinyint(2) NOT NULL,
  `description` text NOT NULL,
  `featured` char(1) DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `address` text NOT NULL,
  `services` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `date_added` int(10) NOT NULL,
  `date_modified` int(10) NOT NULL,
  PRIMARY KEY (`property_id`),
  KEY `owner_id` (`user_id`),
  KEY `property_type_id` (`property_type_id`),
  KEY `area_id` (`zone_id`),
  KEY `property_status_id` (`property_status_id`),
  KEY `status` (`status`),
  KEY `featured` (`featured`),
  CONSTRAINT `property_ibfk_2` FOREIGN KEY (`property_type_id`) REFERENCES `property_type` (`property_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `property_ibfk_4` FOREIGN KEY (`property_status_id`) REFERENCES `property_status` (`property_status_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `property_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `property_zone` FOREIGN KEY (`zone_id`) REFERENCES `zone` (`zone_id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `property` (`property_id`, `property_type_id`, `property_status_id`, `title`, `price`, `area`, `zone_id`, `map_lat`, `map_lng`, `map_zoom`, `description`, `featured`, `user_id`, `address`, `services`, `status`, `date_added`, `date_modified`) VALUES
(3,	7,	3,	'',	12345,	0,	3,	'',	'',	0,	'as gaskdg las das',	'',	1,	'',	'',	0,	1406382791,	1406382791),
(4,	7,	3,	'',	87654,	0,	3,	'',	'',	0,	'hdfhfhfhgf',	'',	1,	'',	'',	0,	1406404745,	1406404745),
(5,	7,	3,	'',	332,	0,	3,	'',	'',	0,	'345dfgdg',	'',	1,	'',	'',	0,	1406460851,	1406460851),
(6,	7,	3,	'',	23123,	0,	3,	'',	'',	0,	'sfsdfds',	'',	1,	'',	'',	0,	1406461677,	1406461677),
(7,	7,	3,	'',	34567,	0,	3,	'',	'',	0,	'sdfds',	'',	1,	'',	'',	0,	1406473640,	1406473640),
(8,	7,	3,	'',	9876543,	0,	3,	'',	'',	0,	'sdfsd fsd fsd d',	'',	1,	'',	'',	0,	1406473865,	1406473865),
(9,	7,	3,	'عقار للبيع على الطريق المحوري',	34534534,	2000,	3,	'32.708078868917546',	'36.56760960817337',	18,	'34256787',	'',	1,	'',	'',	1,	1406473883,	1406838422),
(10,	7,	3,	'شسي شسيشس شس',	322,	3434534,	3,	'32.72107515447069',	'36.58012521377873',	17,	'خلافاَ للإعتقاد السائد فإن لوريم إيبسوم ليس نصاَ عشوائياً، بل إن له جذور في الأدب اللاتيني الكلاسيكي منذ العام 45 قبل الميلاد، مما يجعله أكثر من 2000 عام في القدم. قام البروفيسور \"ريتشارد ماك لينتوك\".',	'1',	1,	'هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية.',	'لوريم إيبسوم(Lorem Ipsum) هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم .',	1,	1406481019,	1406837911);

DROP TABLE IF EXISTS `property_image`;
CREATE TABLE `property_image` (
  `property_image_id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(200) NOT NULL,
  `orig_name` varchar(200) NOT NULL,
  `brief` tinytext NOT NULL,
  `property_id` int(10) unsigned NOT NULL,
  `image_type` char(1) NOT NULL,
  `date_added` int(10) NOT NULL,
  `date_modified` int(10) NOT NULL,
  PRIMARY KEY (`property_image_id`),
  KEY `property_id` (`property_id`),
  CONSTRAINT `property_image_ibfk_2` FOREIGN KEY (`property_id`) REFERENCES `property` (`property_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `property_image` (`property_image_id`, `filename`, `orig_name`, `brief`, `property_id`, `image_type`, `date_added`, `date_modified`) VALUES
(1,	'890d3f0e514275247f99dc83c8825fa4.png',	'Screenshot_from_.png',	'',	3,	'',	1406382791,	1406382791),
(2,	'22dc670d639f0df696c9ed3e740f4304.jpg',	'photo.jpg',	'',	4,	'',	1406404745,	1406404745),
(3,	'a8dd7a9df9da0538673f423b0a7dc8f6.png',	'4.png',	'',	5,	'',	1406460851,	1406460851),
(4,	'4df24df16851d0ced8e87635a2cd53cd.png',	'Screenshot_2013-.png',	'',	6,	'',	1406461677,	1406461677),
(5,	'7b2281b6a523eccf5eab6dc59637affd.jpg',	'photo.jpg',	'',	7,	'',	1406473640,	1406473640),
(6,	'd039ef0231d749c4c592c9d04fde3863.png',	'03.png',	'',	8,	'',	1406473865,	1406473865),
(7,	'021a6e82453610a2c445a18803b91e6a.png',	'01.png',	'',	9,	'',	1406473883,	1406473883),
(8,	'1df6fdd38fa026e5d3a689d7c0f8f250.jpg',	'photo.jpg',	'',	10,	'',	1406835092,	1406835092);

DROP TABLE IF EXISTS `property_status`;
CREATE TABLE `property_status` (
  `property_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `property_status_name` varchar(50) NOT NULL,
  `date_added` int(10) NOT NULL,
  `date_modified` int(10) NOT NULL,
  PRIMARY KEY (`property_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `property_status` (`property_status_id`, `property_status_name`, `date_added`, `date_modified`) VALUES
(3,	'بيع',	0,	0);

DROP TABLE IF EXISTS `property_type`;
CREATE TABLE `property_type` (
  `property_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `property_type_name` varchar(200) NOT NULL,
  `date_added` int(10) NOT NULL,
  `date_modified` int(10) NOT NULL,
  PRIMARY KEY (`property_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `property_type` (`property_type_id`, `property_type_name`, `date_added`, `date_modified`) VALUES
(7,	'شقة',	0,	0);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(15) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1,	'127.0.0.1',	'administrator',	'$2a$07$SeBknntpZror9uyftVopmu61qg0ms8Qv1yV6FG.kQOSM.9QhmTo36',	'',	'admin@admin.com',	'',	NULL,	NULL,	NULL,	1268889823,	1268889823,	1,	'Admin',	'istrator',	'ADMIN',	'0');

DROP TABLE IF EXISTS `users_groups`;
CREATE TABLE `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`),
  CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1,	1,	1),
(2,	1,	2);

DROP TABLE IF EXISTS `zone`;
CREATE TABLE `zone` (
  `zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) NOT NULL,
  `map_latlng` varchar(45) DEFAULT NULL,
  `map_zoom` tinyint(4) DEFAULT NULL,
  `date_added` int(10) NOT NULL,
  `date_modified` int(10) NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `zone` (`zone_id`, `zone_name`, `map_latlng`, `map_zoom`, `date_added`, `date_modified`) VALUES
(3,	'قنوات',	NULL,	NULL,	0,	0);

-- 2014-08-01 14:39:33
