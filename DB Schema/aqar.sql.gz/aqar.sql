-- Adminer 4.1.0 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1,	'admin',	'Administrator'),
(2,	'members',	'General User'),
(3,	'zone_manager',	'Zone Manager');

DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `project`;
CREATE TABLE `project` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `address` text NOT NULL,
  `area` varchar(25) NOT NULL,
  `description` text NOT NULL,
  `services` text NOT NULL,
  `youtube_url` tinytext NOT NULL,
  `project_name` varchar(200) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `company_type` char(1) NOT NULL,
  `person_name` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `zone_id` int(11) NOT NULL,
  `map_lat` varchar(50) NOT NULL,
  `map_lng` varchar(50) NOT NULL,
  `map_zoom` int(11) NOT NULL,
  `date_added` int(10) NOT NULL,
  `date_modified` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '2',
  PRIMARY KEY (`project_id`),
  KEY `zone_id` (`zone_id`),
  CONSTRAINT `project_ibfk_1` FOREIGN KEY (`zone_id`) REFERENCES `zone` (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `project` (`project_id`, `address`, `area`, `description`, `services`, `youtube_url`, `project_name`, `company_name`, `company_type`, `person_name`, `email`, `mobile`, `zone_id`, `map_lat`, `map_lng`, `map_zoom`, `date_added`, `date_modified`, `status`) VALUES
(2,	'',	'',	'',	'',	'',	'مشروع برج الريم',	'اليسر العقارية',	'b',	'حسان الباروكي',	'hassan.albaruki@gmail.com',	'0933067744',	3,	'0',	'0',	0,	1408036131,	1408037630,	2),
(3,	'هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص.',	'3000',	'لوريم إيبسوم(Lorem Ipsum) هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر عندما قامت مطبعة مجهولة برص مجموعة من الأحرف بشكل عشوائي أخذتها من نص، لتكوّن كتيّب بمثابة دليل أو مرجع شكلي لهذه الأحرف. خمسة قرون من الزمن لم تقضي على هذا النص، بل انه حتى صار مستخدماً وبشكله الأصلي في الطباعة والتنضيد الإلكتروني. انتشر بشكل كبير في ستينيّات هذا القرن مع إصدار رقائق \"ليتراسيت\" (Letraset) البلاستيكية تحوي مقاطع من هذا النص، وعاد لينتشر مرة أخرى مؤخراَ مع ظهور برامج النشر الإلكتروني مثل \"ألدوس بايج مايكر\" (Aldus PageMaker) والتي حوت أيضاً على نسخ من نص لوريم إيبسوم.',	'هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام \"هنا يوجد محتوى نصي، هنا يوجد محتوى نصي\" فتجعلها تبدو (أي الأحرف) وكأنها نص مقروء. العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال \"lorem ipsum\" في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.',	'https://www.youtube.com/watch?v=7u4eTOy1Clc',	'برج الدانا',	'الفجر للتطوير العقاري',	'',	'حسان الباروكي',	'hassan.albaruki@gmail.com',	'0933067744',	3,	'32.492298121522545',	'36.710042618215084',	17,	1408036179,	1408054461,	2),
(4,	'',	'',	'',	'',	'',	'برج الخيام',	'الفجر للتطوير العقاري',	'a',	'حسان الباروكي',	'hassan.albaruki@gmail.com',	'0933067744',	3,	'0',	'0',	0,	1408036229,	1408054472,	1),
(5,	'شرق ساحة تشرين',	'1200',	'ض',	'ض',	'https://www.youtube.com/watch?v=Qwa6q8jWTz4',	'مدينة النور',	'الفجر للتطوير العقاري',	'',	'حسان الباروكي',	'hassan.albaruki@gmail.com',	'09336228',	3,	'32.71416778667088',	'36.571018025279045',	16,	1408036314,	1408054467,	1);

DROP TABLE IF EXISTS `project_image`;
CREATE TABLE `project_image` (
  `project_image_id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(200) NOT NULL,
  `orig_name` varchar(200) NOT NULL,
  `brief` tinytext NOT NULL,
  `project_image_type` char(1) NOT NULL,
  `project_id` int(11) NOT NULL,
  `date_added` int(10) NOT NULL,
  `date_modified` int(10) NOT NULL,
  PRIMARY KEY (`project_image_id`),
  KEY `project_id` (`project_id`),
  CONSTRAINT `project_fk` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `project_image` (`project_image_id`, `filename`, `orig_name`, `brief`, `project_image_type`, `project_id`, `date_added`, `date_modified`) VALUES
(11,	'6c992fdc77801803a47349a6509ae648.JPG',	'Home_Properties_.JPG',	'',	'',	5,	1408038142,	1408038142),
(12,	'bcf4fb19e6bff260c4ad5c2fcd33847e.jpg',	'75603_1072009313.jpg',	'',	'',	5,	1408038147,	1408038147),
(13,	'75c1c1bafdf5aff8fbf24802b784ecd4.jpg',	'bdf7bac4b6ee28c0.jpg',	'',	'',	5,	1408038154,	1408038154),
(14,	'6c67b63166da8eb16fbd431825d7141f.jpg',	'DAMAC_PROPERTIES.jpg',	'',	'',	4,	1408043556,	1408043556),
(15,	'97ea3a4f86afa49b598f577aef830fbd.jpg',	'hotele.jpg',	'',	'',	4,	1408043561,	1408043561),
(16,	'a8435d6ec5751af703f2028841e41be4.jpg',	'Glenroy-NRAS-pro.jpg',	'',	'',	4,	1408043569,	1408043569),
(17,	'0d7471f4a07d902b4af52327fb89110a.jpg',	'gagan_emerald_by.jpg',	'',	'',	3,	1408043699,	1408043699),
(18,	'969f2dcacb20a00a5bd4aa094e8b97ee.jpeg',	'f_1136527_12979.jpeg',	'',	'',	3,	1408043709,	1408043709);

DROP TABLE IF EXISTS `property`;
CREATE TABLE `property` (
  `property_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `property_type_id` int(11) NOT NULL,
  `property_status_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `price` int(20) NOT NULL,
  `area` int(20) NOT NULL,
  `zone_id` int(11) NOT NULL,
  `map_lat` varchar(200) NOT NULL,
  `map_lng` varchar(200) NOT NULL,
  `map_zoom` tinyint(2) NOT NULL,
  `description` text NOT NULL,
  `featured` char(1) DEFAULT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `address` text NOT NULL,
  `services` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `date_added` int(10) NOT NULL,
  `date_modified` int(10) NOT NULL,
  `ref_number` varchar(20) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`property_id`),
  KEY `owner_id` (`user_id`),
  KEY `property_type_id` (`property_type_id`),
  KEY `area_id` (`zone_id`),
  KEY `property_status_id` (`property_status_id`),
  KEY `status` (`status`),
  KEY `featured` (`featured`),
  KEY `ref_number` (`ref_number`),
  CONSTRAINT `property_ibfk_6` FOREIGN KEY (`ref_number`) REFERENCES `property_reference` (`ref_number`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `property_ibfk_2` FOREIGN KEY (`property_type_id`) REFERENCES `property_type` (`property_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `property_ibfk_4` FOREIGN KEY (`property_status_id`) REFERENCES `property_status` (`property_status_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `property_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `property_zone` FOREIGN KEY (`zone_id`) REFERENCES `zone` (`zone_id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `property` (`property_id`, `property_type_id`, `property_status_id`, `title`, `price`, `area`, `zone_id`, `map_lat`, `map_lng`, `map_zoom`, `description`, `featured`, `user_id`, `address`, `services`, `status`, `date_added`, `date_modified`, `ref_number`) VALUES
(6,	7,	3,	'',	23123,	0,	3,	'',	'',	0,	'sfsdfds',	'',	1,	'',	'',	0,	1406461677,	1406461677,	'4100'),
(9,	8,	3,	'عقار للبيع على الطريق المحوري',	34534534,	2000,	3,	'32.708078868917546',	'36.56760960817337',	18,	'34256787',	'1',	1,	'',	'',	1,	1406473883,	1406838422,	'4102'),
(10,	10,	3,	'شسي شسيشس شس',	322,	3434534,	3,	'32.72107515447069',	'36.58012521377873',	17,	'خلافاَ للإعتقاد السائد فإن لوريم إيبسوم ليس نصاَ عشوائياً، بل إن له جذور في الأدب اللاتيني الكلاسيكي منذ العام 45 قبل الميلاد، مما يجعله أكثر من 2000 عام في القدم. قام البروفيسور \"ريتشارد ماك لينتوك\".',	'1',	1,	'هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية.',	'لوريم إيبسوم(Lorem Ipsum) هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم .',	1,	1406481019,	1406837911,	'4103'),
(11,	7,	3,	'fsd fsd f',	12345678,	3432423,	3,	'32.712976215015026',	'36.5665340423584',	17,	'عقار جميل جداً مساحته 2300 متر مربع',	'1',	2,	'0',	'',	1,	1406918203,	1407719456,	'4104'),
(12,	9,	4,	'محل تجاري بوسط السوق',	2000,	60,	3,	'32.71098571322407',	'36.56746946275234',	20,	'محل تجاري طابقين و مستودع صغير',	'1',	2,	'0',	'',	1,	1407797370,	1407797443,	'4105'),
(15,	8,	4,	'',	342,	0,	4,	'',	'',	0,	'dsfds',	NULL,	2,	'',	'',	0,	1408054170,	1408054170,	'4101');

DROP TABLE IF EXISTS `property_image`;
CREATE TABLE `property_image` (
  `property_image_id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(200) NOT NULL,
  `orig_name` varchar(200) NOT NULL,
  `brief` tinytext NOT NULL,
  `property_id` int(10) unsigned NOT NULL,
  `image_type` char(1) NOT NULL,
  `date_added` int(10) NOT NULL,
  `date_modified` int(10) NOT NULL,
  PRIMARY KEY (`property_image_id`),
  KEY `property_id` (`property_id`),
  CONSTRAINT `property_image_ibfk_2` FOREIGN KEY (`property_id`) REFERENCES `property` (`property_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `property_image` (`property_image_id`, `filename`, `orig_name`, `brief`, `property_id`, `image_type`, `date_added`, `date_modified`) VALUES
(4,	'4df24df16851d0ced8e87635a2cd53cd.png',	'Screenshot_2013-.png',	'',	6,	'',	1406461677,	1406461677),
(7,	'021a6e82453610a2c445a18803b91e6a.png',	'01.png',	'',	9,	'',	1406473883,	1406473883),
(8,	'1df6fdd38fa026e5d3a689d7c0f8f250.jpg',	'photo.jpg',	'',	10,	'',	1406835092,	1406835092),
(9,	'b523957247a7eda33d5bfda6f27425a5.png',	'Screenshot_from_.png',	'',	11,	'',	1406918203,	1406918203),
(10,	'a76e311f2f763827d05fa3bf335eaf6d.jpg',	'photo.jpg',	'',	11,	'',	1407692884,	1407692884),
(11,	'6225f5da13fe6d00b342ca62d0629e36.png',	'Screenshot_from_.png',	'',	12,	'',	1407797370,	1407797370),
(12,	'51b69fe916534a506101ab24c10361ed.jpg',	'photo.jpg',	'',	15,	'',	1408054170,	1408054170);

DROP TABLE IF EXISTS `property_reference`;
CREATE TABLE `property_reference` (
  `ref_number` varchar(20) NOT NULL,
  `area` varchar(20) NOT NULL,
  UNIQUE KEY `ref_number` (`ref_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `property_reference` (`ref_number`, `area`) VALUES
('4100',	'500'),
('4101',	'400'),
('4102',	''),
('4103',	''),
('4104',	''),
('4105',	''),
('4106',	''),
('4107',	''),
('4108',	''),
('4109',	''),
('4110',	''),
('4111',	'');

DROP TABLE IF EXISTS `property_status`;
CREATE TABLE `property_status` (
  `property_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `property_status_name` varchar(50) NOT NULL,
  `date_added` int(10) NOT NULL,
  `date_modified` int(10) NOT NULL,
  PRIMARY KEY (`property_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `property_status` (`property_status_id`, `property_status_name`, `date_added`, `date_modified`) VALUES
(3,	'البيع',	0,	0),
(4,	'الإيجار',	0,	0);

DROP TABLE IF EXISTS `property_type`;
CREATE TABLE `property_type` (
  `property_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `property_type_name` varchar(200) NOT NULL,
  `date_added` int(10) NOT NULL,
  `date_modified` int(10) NOT NULL,
  `marker_icon` varchar(150) NOT NULL,
  PRIMARY KEY (`property_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `property_type` (`property_type_id`, `property_type_name`, `date_added`, `date_modified`, `marker_icon`) VALUES
(7,	'شقق',	0,	0,	'house2.png'),
(8,	'أراضي',	0,	0,	'house.png'),
(9,	'محلات تجارية',	0,	0,	'house1.png'),
(10,	'محلات صناعية',	0,	0,	'house3.png'),
(11,	'مستودعات',	0,	0,	'house4.png'),
(12,	'منازل عربية',	0,	0,	'house5.png');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(15) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1,	'127.0.0.1',	'administrator',	'$2a$07$SeBknntpZror9uyftVopmu61qg0ms8Qv1yV6FG.kQOSM.9QhmTo36',	'',	'admin@admin.com',	'',	NULL,	NULL,	'UnqEcm/ezed8aL6qOTUonu',	1268889823,	1408059513,	1,	'صالح',	'سعيد',	'ADMIN',	'0933067744'),
(2,	'127.0.0.1',	'صالح سعيد',	'$2y$08$FS/FEPStDk7YY3Yxv1xIYuyyCXTNM7mKfSZuhT6dKA65WBMH2FUDe',	NULL,	'saleh.saiid@gmail.com',	'',	NULL,	NULL,	'L546mPOSs5vjem714Uj5Ru',	1406916470,	1408059396,	1,	'عمر',	'سعيد',	NULL,	'0933067744'),
(3,	'127.0.0.1',	'حسان الباروكي',	'$2y$08$oo6zTEYnXngfvR9Trm6icO0QNhgfZZM7dVkoF/VQo8HrWaR1UmXrK',	NULL,	'hassan.albaruki@gmail.com',	NULL,	NULL,	NULL,	'0q7twoI/Ycq4Jb58M5P6p.',	1406916850,	1408057568,	1,	'حسان',	'الباروكي',	NULL,	'099876543');

DROP TABLE IF EXISTS `users_groups`;
CREATE TABLE `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`),
  CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1,	1,	1),
(3,	2,	2),
(4,	3,	2);

DROP TABLE IF EXISTS `zone`;
CREATE TABLE `zone` (
  `zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) NOT NULL,
  `map_lat` varchar(45) DEFAULT NULL,
  `map_lng` varchar(45) DEFAULT NULL,
  `map_zoom` tinyint(4) DEFAULT NULL,
  `date_added` int(10) NOT NULL,
  `date_modified` int(10) NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `zone` (`zone_id`, `zone_name`, `map_lat`, `map_lng`, `map_zoom`, `date_added`, `date_modified`) VALUES
(3,	'قنوات',	NULL,	NULL,	NULL,	0,	0),
(4,	'الرحى',	'32.6785040203332',	'36.60198077559471',	15,	1407719215,	1407719215);

-- 2014-08-14 23:41:35
